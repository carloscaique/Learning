//Variáveis Bolinha
let xBolinha = 400;
let yBolinha = 270;
let diametroBolinha = 35;
let raio = diametroBolinha / 2;

//Velocidade Bolinha
let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;

//Variáveis da Raquete
let xRaquete = 5;
let yRaquete = 30;
let comprimentoRaquete = 10; 
let alturaRaquete = 90;

function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(0);
  mostraBolinha();
  mostraRaquete();
  //movimentaBolinha();
  movimentaRaquete();
  verificaColisaoBorda();
  
}

function mostraBolinha(){
  circle (xBolinha, yBolinha, diametroBolinha);
}

function movimentaBolinha(){
  xBolinha += velocidadeXBolinha;
  yBolinha -= velocidadeYBolinha;
}

function verificaColisaoBorda() {
  
  if (xBolinha + raio > width || xBolinha - raio < 0){
    velocidadeXBolinha *= -1;
  }
  

  if (yBolinha + raio > height || yBolinha - raio < 0){
    velocidadeYBolinha *= -1;
  }
}

function mostraRaquete(){
  rect (xRaquete, yRaquete, comprimentoRaquete, alturaRaquete);
}

function movimentaRaquete(){
  if (keyIsDown(UP_ARROW)){
    yRaquete -= 10;
    }
 if (keyIsDown (DOWN_ARROW)){
   yRaquete += 10;
 }
}
  


